﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace crud_operation_mvc.Models
{
    public class employeecommands
    {
        private SqlConnection conn = null;

        private void ConnectionReturn()
        {
            string ConnString = ConfigurationManager.ConnectionStrings["dbms"].ConnectionString;
            conn=new SqlConnection(ConnString);
        }

        public List<employee> GetAllemployeeData()
        {
            ConnectionReturn();
            List<employee> employees = new List<employee>();
            string Getemployee = "select * from [dbo].[employee]";
            conn.Open();
            SqlCommand cmd = new SqlCommand(Getemployee, conn);
            SqlDataReader dr = cmd.ExecuteReader();
            if(dr.HasRows)
            {
                while(dr.Read())
                {
                    employee Employee = new employee();
                    Employee.empid = Convert.ToInt32(dr["empid"]);
                    Employee.name = Convert.ToString(dr["name"]);
                    Employee.address = Convert.ToString(dr["address"]);
                    Employee.CityId = Convert.ToInt32(dr["CityId"]);
                    employees.Add(Employee);
                }
            }
            conn.Close();
            return employees;
        }

        public List<Citys> FillCitysDropDown()
        {
            ConnectionReturn();
            List<Citys> citys = new List<Citys>();
            string Getemployee = "select * from [dbo].[Citys]";
            conn.Open();
            SqlCommand cmd = new SqlCommand(Getemployee, conn);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    Citys city = new Citys();
                    city.CityId = Convert.ToInt32(dr["CityId"]);
                    city.CityName = Convert.ToString(dr["CityName"]);
                    citys.Add(city);
                }
            }
            conn.Close();
            return citys;
        }

        public bool InsertEmployeeData(employee emp)
        {


            ConnectionReturn();
            string InsertData = "insert into [dbo].[employee] (empid,name,address,CityId) values("+emp.empid+",'"+emp.name+"','"+emp.address+"','"+emp.CityId+"')";
            conn.Open();
            SqlCommand cmd = new SqlCommand(InsertData, conn);
            int status=cmd.ExecuteNonQuery();
            conn.Close() ;
            if(status>0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public bool EditEmployeeData(employee emp)
        {
            ConnectionReturn();
            string UpdateData = "update [dbo].[employee] set name='"+emp.name+"',address='"+emp.address+"', CityId = '"+emp.CityId+"' where empid="+ emp.empid +"";
            conn.Open();
            SqlCommand cmd = new SqlCommand(UpdateData, conn);
            int status = cmd.ExecuteNonQuery();
            conn.Close();
            if (status > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool DeleteEmployeeData(int emp)
        {


            ConnectionReturn();
            string DeleteData = "delete from [dbo].[employee] where empid="+ emp +"";
            conn.Open();
            SqlCommand cmd = new SqlCommand(DeleteData, conn);
            int status = cmd.ExecuteNonQuery();
            conn.Close();
            if (status > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}