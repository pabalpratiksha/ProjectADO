﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace crud_operation_mvc.Models
{
    public class employee
    {
        public int empid { get; set; }
        public string name { get; set; }
        public string address { get; set; }
        public List<Citys> Citys { get; set; }
        public int CityId { get; set; }
    }
}