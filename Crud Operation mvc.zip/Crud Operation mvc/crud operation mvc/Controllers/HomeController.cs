﻿using crud_operation_mvc.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace crud_operation_mvc.Controllers
{
    public class HomeController : Controller
    {
        employeecommands Command=new employeecommands();
        public ActionResult Index()
        {
            List<employee> emplist = Command.GetAllemployeeData().ToList();
            return View(emplist);
        }
        public ActionResult create()
        {
            var CitiesList = Command.FillCitysDropDown().ToList();
            ViewBag.Cities = CitiesList;
            return View();
        }
        [HttpPost]
        public ActionResult create(employee emp)
        {
            bool status=Command.InsertEmployeeData(emp);    
            if(status==true)
            {
                TempData["message"] = "<script>alert('data inserted')</script>";
                return RedirectToAction("Index");
            }
            return View();
        }

        public ActionResult Edit(int id)
        {
            var CitiesList = Command.FillCitysDropDown().ToList();
            ViewBag.Cities = CitiesList;
            employee emplist = Command.GetAllemployeeData().Find(x => x.empid == id);
            return View(emplist);

        }
        [HttpPost]
        public ActionResult Edit(employee emp)
        {

            bool status = Command.EditEmployeeData(emp);
            if (status == true)
            {
                return RedirectToAction("Index");
            }
            return View();
        }
        public ActionResult Delete(int id)
        {
            bool Status = Command.DeleteEmployeeData(id);
            if (Status == true)
            {
                return RedirectToAction("Index");
            }
            return View();
        }
        public ActionResult Details(int id)
        {
            employee emplist = Command.GetAllemployeeData().Find(x => x.empid == id);
            return View(emplist);
        }

    }
}